const fs = require('fs');
const proces = require('process');
const axios = require('axios');
const argsv = process.argv
let inputFile = argsv[2]

// Read file containing url links
function linksFile(readFrom) {
    fs.readFile(readFrom, 'utf8', function (err, data) {
        if (err) {
            console.error(`Error: Cannot read ${readFrom}.`)
            process.exit(1);
        } else {
            processSite(data);
        }
    })
}

// Process site data with urls seperated by line breaks. Will write all accessibly urls to directory called in with hostnames as file name.
function processSite(data) {
    let urls = data.split("\n");
    let promises = [];
    for (let i = 0; i < urls.length; i++) {
        const url = new URL(urls[i]);
        promises.push(axios.get(url.href)
            .then((result) => {
                writeFile(result.data, url.hostname);
            })
            .catch(function (err) {
                console.error(`Couldn't download: ${err.hostname}`);
            }));

    };
    return Promise.all(promises);
}

// Writes a file. 
function writeFile(text, hostname) {
    fs.writeFile(hostname, text, 'utf8', function (err) {
        if (err) {
            console.error(`Couldn't download ${hostname}.`);
            process.exit(1);
        }
        console.log(`Wrote to ${hostname}`);
    })
};

linksFile(inputFile);