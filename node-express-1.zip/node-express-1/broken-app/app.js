const express = require('express');
const axios = require('axios');
const app = express();
const ExpressError = require("./expressError")

app.use(express.json());

/** Get github data for a list of developers.
 * 
Request format: { "developers": ["joelburton", "elie"] } 
Return response: [
  {"name": "Joel Burton","bio": "Open source developer...},
  {"name": "Elie Schoppik","bio": "Co-founder ..."}]
*/
app.post('/', async function (req, res, next) {
  try {
    const devList = req.body.developers;
    // Check for valid inputs
    if (devList === undefined || devList.includes("")) {
      throw new ExpressError("Please make sure to input a valid developer data.");
    }

    let developersData = [];
    for (let i = 0; i < devList.length; i++) {
      developersData.push(await axios.get(`https://api.github.com/users/${devList[i]}`))
    }

    let devOutput = developersData.map(developer => ({ name: developer.data.name, bio: developer.data.bio }));

    return res.send(JSON.stringify(devOutput));
  } catch (err) {
    next(err);
  }
});

/** general error handler */

app.use((err, req, res, next) => {
  res.status(err.status || 500);

  return res.json({
    error: err.message,
  });
});


app.listen(3000);
