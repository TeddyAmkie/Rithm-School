# Broken App Issues

- Fixed function to be async so await request will be fulfilled.
- Renamed several variables to reduce ambiguity
- Passed proper parameter to catch
- Catch passing errors to missing error handler. Addded general error handler.
- app and axios declarations used var/let. Changed to const.
- Added express.json middleware to parse body of post requests.
- Cannot await inside a map function without creating an additional object to put data in. Re-wrote as for loop for better readability.
- Added docstring with expected input / output format.