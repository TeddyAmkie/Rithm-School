### Conceptual Exercise

Answer the following questions below:

- What are some ways of managing asynchronous code in JavaScript?
You can manage async code in JS with promises in few different ways depending on the situation. 
 -- Making the function async and calling await on the promise is great when you need to make calls one at a time in order.  The syntax is clean.

 -- Promise class -- some very useful functions such as:
   - Order irrelevant/send out together: Promise.all
   - First promise to resolve: Promise.race
   and many more, with the ability to make your own. 
   - can also use .then to chain promises(and .catch for rejections)
  
Order is extremely important when working with promises, as well as readability as code can get messy quick with a lot of promises.

- What is a Promise?
A promise is an object used when working with async operations. The promise guarantees that once the operation is complete,
 it will either resolve and succesfully return the resulting value, or be rejected and return with an error.

- What are the differences between an async function and a regular function?
JS is single-threaded and can only complete one operation a time. While a regular function can be added to the stack/event queue and other 

- What is the difference between Node.js and Express.js?
Node is a javascript environment to run code outside the browser. It gives us the ability to read/write files in JS.
  Node comes with npm, a package manager with extensive features and countless add-on libraries.
Express is a web app framework that we run on Node that allows us to creates a server that receives requests, return responses,
 and handle the logic in-between.
- What is the error-first callback pattern?
It prevents having to process data if there would be an error regardless of the data values. It also helps keep a standard amongst code,
making it easier to work/maintain code.
- What is middleware?
Middleware is any function that goes between the request/response cycle. 

- What does the `next` function do?
The next function goes to the next function in code. This is useful for when middleware completes its operation, 
it will go directly to the view function or next middleware when it isn't called with a paramater.

When the next function is called with a parameter, it goes directly to the error handler. 
- What does `RETURNING` do in SQL? When would you use it?
`RETURNING` returns whatever data was being processed. For example, if the SQL command was inserting data, it will return what was inserted. 
- What are some issues with the following code? (consider all aspects: performance, structure, naming, etc)

  Performance:
    - Time: 
            - The API calls happen in order. I could use a Promise.all() so all the API calls are made at the same time and return when they're done.
              With this code, I have to make the API call for elie, wait for it to return, then begin joel ....and so on.
            - If I want to get data for just elie I'd have the Promise resolved for elie but STILl have to wait. Likewise, if I want data for matt,
              I would be making unncessary API calls with useless data(sorry elie and joel) before I even began to make the api call for matt.

  Naming:
    elie/joel/matt could be assumed to be anything from anywhere. elieGithubJson could give some abstraction to someone who
    may never see this code and will know exactly what data we're getting and from where.
    getUsers is very vague as well. The example using celebrities aside, we're getting 3 random github users information.
    getRithmInstructors would bring some category to group them under that would be much more informative.

  Structure:
    We must make an API call everytime we run the function. Using a Class would bring a lot of value in most situations. Making one api call, 
    and accessing any data necessary by calling methods on that class would bring a lot of abstraction making it very easy for anyone working
    with the codebase to not need to know how we are getting the user and what data and format, but simply looking at the class methods.
  
Overall, the code feels very heavy and while it may be a quick easy way to get data for a personal project, it will not scale.
            

```js
async function getUsers() {
  const elie = await $.getJSON('https://api.github.com/users/elie');
  const joel = await $.getJSON('https://api.github.com/users/joelburton');
  const matt = await $.getJSON('https://api.github.com/users/mmmaaatttttt');

  return [elie, matt, joel];
}
```
