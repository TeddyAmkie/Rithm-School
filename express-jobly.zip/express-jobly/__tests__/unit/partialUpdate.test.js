describe("partialUpdate()", () => {
  it("should generate a proper partial update query with just 1 field",
      function () {

    // FIXME: write real tests!
    expect(false).toEqual(true);

  });
});
